import { useEffect, useRef } from "react";
import Game from "./components/Game";
import "./index.css";

function App() {
  return (
    <div className="w-full h-full bg-gray-900 flex items-center justify-center">
      <Game />
    </div>
  );
}

export default App;
