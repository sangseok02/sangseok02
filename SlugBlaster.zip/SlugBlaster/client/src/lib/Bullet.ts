export class Bullet {
  public x: number;
  public y: number;
  public width: number = 8;
  public height: number = 3;
  public pierce: boolean;
  public color: string;
  private velocityX: number;
  private velocityY: number;

  constructor(x: number, y: number, velocityX: number, velocityY: number, color: string = "#FFEB3B", pierce: boolean = false) {
    this.x = x;
    this.y = y;
    this.velocityX = velocityX;
    this.velocityY = velocityY;
    this.color = color;
    this.pierce = pierce;
  }

  update(deltaTime: number) {
    this.x += this.velocityX * (deltaTime / 1000);
    this.y += this.velocityY * (deltaTime / 1000);
  }

  render(ctx: CanvasRenderingContext2D) {
    // Draw bullet with weapon color
    ctx.fillStyle = this.color;
    ctx.fillRect(this.x, this.y, this.width, this.height);
    
    // Add a small glow effect with lighter shade
    ctx.fillStyle = this.color + "80"; // Add transparency
    ctx.fillRect(this.x + 1, this.y + 1, this.width - 2, this.height - 2);
    
    // Special effect for laser bullets
    if (this.pierce) {
      ctx.shadowColor = this.color;
      ctx.shadowBlur = 5;
      ctx.fillRect(this.x, this.y, this.width, this.height);
      ctx.shadowBlur = 0;
    }
  }
}
