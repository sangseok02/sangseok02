
import { Weapon } from "./Weapon";

export class WeaponBox {
  public x: number;
  public y: number;
  public width: number = 32;
  public height: number = 32;
  public weapon: Weapon;
  private animationFrame: number = 0;

  constructor(x: number, y: number, weapon: Weapon) {
    this.x = x;
    this.y = y;
    this.weapon = weapon;
  }

  update(deltaTime: number) {
    this.animationFrame += deltaTime * 0.005;
  }

  render(ctx: CanvasRenderingContext2D) {
    // Draw floating effect
    const floatOffset = Math.sin(this.animationFrame) * 2;
    const drawY = this.y + floatOffset;

    // Draw box background
    ctx.fillStyle = "#444444";
    ctx.fillRect(this.x, drawY, this.width, this.height);

    // Draw border
    ctx.strokeStyle = this.weapon.bulletColor;
    ctx.lineWidth = 2;
    ctx.strokeRect(this.x, drawY, this.width, this.height);

    // Draw weapon icon based on type
    ctx.fillStyle = this.weapon.bulletColor;
    ctx.font = "20px Arial";
    ctx.textAlign = "center";
    
    let icon = "🔫";
    if (this.weapon.name === "shotgun") icon = "🔫";
    if (this.weapon.name === "laser") icon = "⚡";
    
    ctx.fillText(icon, this.x + this.width / 2, drawY + this.height / 2 + 6);

    // Draw weapon name
    ctx.font = "10px Arial";
    ctx.fillStyle = "#FFFFFF";
    ctx.fillText(this.weapon.name.toUpperCase(), this.x + this.width / 2, drawY - 5);
  }
}
