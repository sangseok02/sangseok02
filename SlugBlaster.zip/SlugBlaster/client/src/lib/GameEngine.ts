import { Player } from "./Player";
import { Enemy } from "./Enemy";
import { Bullet } from "./Bullet";
import { HitEffect } from "./HitEffect";
import { InputHandler } from "./InputHandler";
import { WeaponBox } from "./WeaponBox";
import { Weapon } from "./Weapon";

export class GameEngine {
  private ctx: CanvasRenderingContext2D;
  private width: number;
  private height: number;
  private player: Player;
  private enemies: Enemy[] = [];
  private bullets: Bullet[] = [];
  private hitEffects: HitEffect[] = [];
  private weaponBoxes: WeaponBox[] = [];
  private inputHandler: InputHandler;
  private hitSound: HTMLAudioElement;
  private animationId: number | null = null;
  private lastTime: number = 0;
  private enemySpawnTimer: number = 0;
  private enemySpawnDelay: number = 2000; // 2 seconds
  private score: number = 0;
  private isPaused: boolean = false;

  public onScoreUpdate?: (score: number) => void;
  public onPlayerHit?: () => void;

  constructor(ctx: CanvasRenderingContext2D, width: number, height: number) {
    this.ctx = ctx;
    this.width = width;
    this.height = height;
    this.player = new Player(100, height - 100, width, height);
    this.inputHandler = new InputHandler();
    
    // Initialize hit sound
    this.hitSound = new Audio('/sounds/hit.mp3');
    this.hitSound.volume = 0.3;
    
    // Listen for pause key
    this.inputHandler.onKeyPress("Escape", () => {
      this.togglePause();
    });

    // Spawn initial weapon boxes
    this.spawnWeaponBoxes();
  }

  start() {
    this.lastTime = performance.now();
    this.gameLoop();
  }

  stop() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
  }

  restart() {
    this.stop();
    this.player = new Player(100, this.height - 100, this.width, this.height);
    this.enemies = [];
    this.bullets = [];
    this.hitEffects = [];
    this.weaponBoxes = [];
    this.score = 0;
    this.enemySpawnTimer = 0;
    this.isPaused = false;
    this.spawnWeaponBoxes();
  }

  togglePause() {
    this.isPaused = !this.isPaused;
    if (!this.isPaused) {
      this.lastTime = performance.now();
      this.gameLoop();
    }
  }

  private gameLoop = () => {
    const currentTime = performance.now();
    const deltaTime = currentTime - this.lastTime;
    this.lastTime = currentTime;

    if (!this.isPaused) {
      this.update(deltaTime);
    }
    
    this.render();

    this.animationId = requestAnimationFrame(this.gameLoop);
  };

  private update(deltaTime: number) {
    // Update player
    this.player.update(deltaTime, this.inputHandler);

    // Handle shooting
    if (this.inputHandler.isKeyPressed("Space") && this.player.canShoot()) {
      const newBullets = this.player.shoot();
      this.bullets.push(...newBullets);
    }

    // Update bullets
    this.bullets = this.bullets.filter(bullet => {
      bullet.update(deltaTime);
      return bullet.x > -50 && bullet.x < this.width + 50 && bullet.y > -50 && bullet.y < this.height + 50;
    });

    // Update weapon boxes
    this.weaponBoxes.forEach(box => box.update(deltaTime));

    // Spawn enemies
    this.enemySpawnTimer += deltaTime;
    if (this.enemySpawnTimer >= this.enemySpawnDelay) {
      this.spawnEnemy();
      this.enemySpawnTimer = 0;
      // Gradually increase spawn rate
      this.enemySpawnDelay = Math.max(500, this.enemySpawnDelay - 50);
    }

    // Update enemies
    this.enemies = this.enemies.filter(enemy => {
      enemy.update(deltaTime);
      
      // Check collision with player
      if (this.checkCollision(this.player, enemy)) {
        this.onPlayerHit?.();
        return false; // Remove enemy
      }
      
      return enemy.x > -50; // Remove enemies that go off screen
    });

    // Update hit effects
    this.hitEffects = this.hitEffects.filter(effect => effect.update(deltaTime));

    // Check weapon pickup collisions
    for (let i = this.weaponBoxes.length - 1; i >= 0; i--) {
      const box = this.weaponBoxes[i];
      if (this.checkCollision(this.player, box)) {
        this.player.pickupWeapon(box.weapon);
        this.weaponBoxes.splice(i, 1);
      }
    }

    // Check bullet-enemy collisions
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const bullet = this.bullets[i];
      for (let j = this.enemies.length - 1; j >= 0; j--) {
        const enemy = this.enemies[j];
        
        if (this.checkCollision(bullet, enemy)) {
          // Remove bullet if it doesn't pierce
          if (!bullet.pierce) {
            this.bullets.splice(i, 1);
          }
          
          // Damage enemy and create hit effect
          const isDead = enemy.takeDamage();
          this.spawnHitEffect(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2);
          this.playHitSound();
          
          if (isDead) {
            // Remove enemy and increase score
            this.enemies.splice(j, 1);
            this.score += 10;
            this.onScoreUpdate?.(this.score);
          }
          
          if (!bullet.pierce) break;
        }
      }
    }
  }

  private render() {
    // Clear canvas
    this.ctx.fillStyle = "#1a1a2e";
    this.ctx.fillRect(0, 0, this.width, this.height);

    // Draw ground
    this.ctx.fillStyle = "#16213e";
    this.ctx.fillRect(0, this.height - 50, this.width, 50);

    // Draw background elements (simple mountains)
    this.ctx.fillStyle = "#0f3460";
    this.ctx.fillRect(0, this.height - 200, this.width, 150);
    
    // Simple mountain silhouette
    this.ctx.beginPath();
    this.ctx.moveTo(0, this.height - 200);
    this.ctx.lineTo(200, this.height - 300);
    this.ctx.lineTo(400, this.height - 250);
    this.ctx.lineTo(600, this.height - 320);
    this.ctx.lineTo(800, this.height - 280);
    this.ctx.lineTo(800, this.height - 200);
    this.ctx.closePath();
    this.ctx.fill();

    // Render game objects
    this.weaponBoxes.forEach(box => box.render(this.ctx));
    this.player.render(this.ctx);
    
    this.bullets.forEach(bullet => bullet.render(this.ctx));
    this.enemies.forEach(enemy => enemy.render(this.ctx));
    this.hitEffects.forEach(effect => effect.render(this.ctx));

    // Draw pause overlay
    if (this.isPaused) {
      this.ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
      this.ctx.fillRect(0, 0, this.width, this.height);
      
      this.ctx.fillStyle = "#ffffff";
      this.ctx.font = "48px Arial";
      this.ctx.textAlign = "center";
      this.ctx.fillText("PAUSED", this.width / 2, this.height / 2);
      
      this.ctx.font = "24px Arial";
      this.ctx.fillText("Press ESC to resume", this.width / 2, this.height / 2 + 50);
    }
  }

  private spawnEnemy() {
    const enemy = new Enemy(
      this.width + 50,
      this.height - 100,
      this.width,
      this.height
    );
    this.enemies.push(enemy);
  }

  private spawnHitEffect(x: number, y: number) {
    this.hitEffects.push(new HitEffect(x, y));
  }

  private playHitSound() {
    this.hitSound.currentTime = 0;
    this.hitSound.play().catch(() => {
      // Ignore audio play errors (e.g., user hasn't interacted with page yet)
    });
  }

  private spawnWeaponBoxes() {
    this.weaponBoxes = [
      new WeaponBox(500, this.height - 132, Weapon.SHOTGUN),
      new WeaponBox(800, this.height - 132, Weapon.LASER)
    ];
  }

  private checkCollision(obj1: any, obj2: any): boolean {
    return (
      obj1.x < obj2.x + obj2.width &&
      obj1.x + obj1.width > obj2.x &&
      obj1.y < obj2.y + obj2.height &&
      obj1.y + obj1.height > obj2.y
    );
  }
}
