
export class HitEffect {
  public x: number;
  public y: number;
  private timer: number;
  private maxTimer: number = 10;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.timer = this.maxTimer;
  }

  update(deltaTime: number): boolean {
    this.timer -= deltaTime / 16.67; // Approximate frame time at 60fps
    return this.timer > 0; // Return false when effect should be removed
  }

  render(ctx: CanvasRenderingContext2D) {
    const alpha = this.timer / this.maxTimer;
    const radius = 6 + (this.maxTimer - this.timer) * 2; // Growing effect
    
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = "#FF9800";
    ctx.beginPath();
    ctx.arc(this.x, this.y, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}
